#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import pymongo
from datetime import datetime

#Configs
MILVUS_HOST = "10.19.48.181"
MILVUS_PORT = "19530"

# 修改用户名和密码 (如果是第5组，请改为 group5 / Group5)
MILVUS_USER = "cs286_2025_group8"
MILVUS_PASSWORD = "Group8"
MILVUS_DB_NAME = "cs286_2025_group8"  # 新增：数据库名字

MONGO_URI = "mongodb://localhost:27017/"
# ===========================================

def get_milvus_connection():
    connection_args = {
        "host": MILVUS_HOST,
        "port": MILVUS_PORT,
    }
    
    if MILVUS_USER and MILVUS_PASSWORD:
        connection_args["user"] = MILVUS_USER
        connection_args["password"] = MILVUS_PASSWORD
        connection_args["db_name"] = MILVUS_DB_NAME  # 添加数据库名字
    return connection_args

def get_mongodb_client(db_name='test_doi'):
    """
    获取 MongoDB 客户端。
    被 process_bibs.py 和 vectorize_bibs.py 调用。
    """
    try:
        # 如果需要认证，请将 MONGO_URI 修改为 'mongodb://user:pass@host:port/'
        client = pymongo.MongoClient(MONGO_URI)
        # 尝试简单的连接检查
        # client.admin.command('ping') 
        return client
    except Exception as e:
        print(f"Error connecting to MongoDB: {e}")
        return None

def format_docs(docs):
    """
    将检索回来的 Document 对象列表拼接成字符串，用于 Prompt Context。
    被 rag.py 调用。
    """
    return "\n\n".join(doc.page_content for doc in docs)

def log_rag(data: dict, use_mongo=False):
    """
    记录问答日志或用户反馈。
    被 chatxfel_app.py 调用。
    
    Args:
        data (dict): 包含日志信息的字典 (如 IP, Question, Answer, Feedback 等)
        use_mongo (bool): 是否将日志存入 MongoDB
    """
    # 1. 打印到终端方便实时查看
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] RAG LOG: {data}")

    # 2. 如果开启，则写入 MongoDB
    if use_mongo:
        try:
            client = get_mongodb_client(db_name="chatxfel_logs")
            if client:
                db = client.get_database("chatxfel_logs")
                col = db.get_collection("access_logs")
                
                # 确保这是一个新字典，以免修改原引用
                log_entry = data.copy()
                if 'timestamp' not in log_entry:
                    log_entry['timestamp'] = datetime.now()
                
                col.insert_one(log_entry)
        except Exception as e:
            print(f"Warning: Failed to log to MongoDB: {e}")